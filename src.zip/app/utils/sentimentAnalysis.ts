// AI-powered sentiment analysis engine
export interface SentimentResult {
  sentiment: 'positive' | 'negative' | 'neutral';
  confidence: number;
  scores: {
    positive: number;
    neutral: number;
    negative: number;
  };
  keywords: Array<{ word: string; sentiment: 'positive' | 'negative' | 'neutral' }>;
}

const positiveWords = [
  'excellent', 'amazing', 'wonderful', 'fantastic', 'great', 'good', 'love', 'best',
  'awesome', 'brilliant', 'outstanding', 'perfect', 'beautiful', 'happy', 'joy',
  'delight', 'pleased', 'satisfied', 'excited', 'enthusiastic', 'positive', 'success',
  'incredible', 'superb', 'magnificent', 'exceptional', 'impressive', 'remarkable',
  'enjoy', 'thanks', 'appreciate', 'grateful', '優秀', 'すばらしい', 'bien', 'gut'
];

const negativeWords = [
  'bad', 'terrible', 'awful', 'horrible', 'poor', 'worst', 'hate', 'disappointing',
  'disappointed', 'sad', 'angry', 'frustrating', 'frustrated', 'useless', 'failure',
  'never', 'waste', 'wrong', 'broken', 'pathetic', 'disgusting', 'annoying', 'irritating',
  'upset', 'unhappy', 'miserable', 'depressed', 'concern', 'worried', 'fear', 'problem'
];

const neutralWords = [
  'okay', 'fine', 'average', 'normal', 'standard', 'typical', 'moderate', 'adequate',
  'acceptable', 'reasonable', 'fair', 'regular', 'common', 'usual'
];

export function analyzeSentiment(text: string): SentimentResult {
  if (!text || text.trim().length === 0) {
    return {
      sentiment: 'neutral',
      confidence: 0,
      scores: { positive: 0, neutral: 0, negative: 0 },
      keywords: []
    };
  }

  const words = text.toLowerCase().match(/\b\w+\b/g) || [];
  const keywords: Array<{ word: string; sentiment: 'positive' | 'negative' | 'neutral' }> = [];
  
  let positiveScore = 0;
  let negativeScore = 0;
  let neutralScore = 0;

  words.forEach(word => {
    if (positiveWords.includes(word)) {
      positiveScore++;
      keywords.push({ word, sentiment: 'positive' });
    } else if (negativeWords.includes(word)) {
      negativeScore++;
      keywords.push({ word, sentiment: 'negative' });
    } else if (neutralWords.includes(word)) {
      neutralScore++;
      keywords.push({ word, sentiment: 'neutral' });
    }
  });

  // Analyze punctuation and capitalization
  const exclamationCount = (text.match(/!/g) || []).length;
  const questionCount = (text.match(/\?/g) || []).length;
  const capitalizedWords = (text.match(/\b[A-Z]{2,}\b/g) || []).length;

  // Boost scores based on punctuation
  if (exclamationCount > 0) {
    positiveScore += exclamationCount * 0.5;
  }
  if (capitalizedWords > 2) {
    negativeScore += capitalizedWords * 0.3;
  }

  const totalScore = positiveScore + negativeScore + neutralScore || 1;
  
  const scores = {
    positive: Math.round((positiveScore / totalScore) * 100),
    neutral: Math.round((neutralScore / totalScore) * 100),
    negative: Math.round((negativeScore / totalScore) * 100)
  };

  // Determine overall sentiment
  let sentiment: 'positive' | 'negative' | 'neutral';
  let confidence: number;

  if (positiveScore > negativeScore && positiveScore > neutralScore) {
    sentiment = 'positive';
    confidence = Math.min(95, 50 + (positiveScore * 5));
  } else if (negativeScore > positiveScore && negativeScore > neutralScore) {
    sentiment = 'negative';
    confidence = Math.min(95, 50 + (negativeScore * 5));
  } else {
    sentiment = 'neutral';
    confidence = Math.max(30, 60 - (Math.abs(positiveScore - negativeScore) * 2));
  }

  // If no sentiment words found, default to neutral with low confidence
  if (totalScore === 1 || keywords.length === 0) {
    return {
      sentiment: 'neutral',
      confidence: 25,
      scores: { positive: 33, neutral: 34, negative: 33 },
      keywords: []
    };
  }

  return {
    sentiment,
    confidence: Math.round(confidence),
    scores,
    keywords: keywords.slice(0, 8) // Top 8 keywords
  };
}

export const exampleTexts = [
  "This product exceeded all my expectations! Absolutely amazing quality and the customer service was outstanding. Highly recommend!",
  "I'm extremely disappointed with this purchase. The quality is terrible and it stopped working after just two days. Complete waste of money.",
  "The item arrived on time and matches the description. It's okay for the price, nothing special but gets the job done.",
  "Wow! This is exactly what I needed. The design is beautiful and it works perfectly. Thank you so much!",
  "Frustrated with the experience. Poor communication, delayed delivery, and the product itself is subpar. Would not buy again."
];
