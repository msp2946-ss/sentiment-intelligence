import { useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { AnalysisPanel } from './components/AnalysisPanel';
import { FeaturesSection } from './components/FeaturesSection';
import { ExamplesSection } from './components/ExamplesSection';
import { Footer } from './components/Footer';
import { ScrollToTop } from './components/ScrollToTop';

export default function App() {
  useEffect(() => {
    // Set default theme to light mode on initial load
    if (!document.documentElement.classList.contains('dark')) {
      document.documentElement.classList.remove('dark');
    }

    // Smooth scroll behavior
    document.documentElement.style.scrollBehavior = 'smooth';
  }, []);

  return (
    <div className="min-h-screen bg-background text-foreground overflow-x-hidden">
      <Navbar />
      <main>
        <Hero />
        <AnalysisPanel />
        <FeaturesSection />
        <ExamplesSection />
      </main>
      <Footer />
      <ScrollToTop />
    </div>
  );
}